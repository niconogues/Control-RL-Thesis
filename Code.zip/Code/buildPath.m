function path = buildPath(path_type)
%   path.x, path.y : coordinates of path samples
%   path.psi       : tangent angle at each sample (path direction)

if nargin < 1
    path_type = 'curve1';
end
s = linspace(0, 1.5, 2001).';     % meaning path from start (0) to end (1), stored as a column vector

if strcmp(lower(path_type), 'curve1')               % Baseline: gentle double sinusoid along the x-axis
    s = linspace(0, 1.5, 2001).';     % meaning path from start (0) to end (1), stored as a column vector
    x = 5.0 * s;                                % path parameter from start (0) to end (1), stored as a column vector
    y = 0.6 * sin(2*pi*s) + 0.3 * sin(4*pi*s);  % Path curve can be changed here

elseif strcmp(lower(path_type), 'curve2')
    % Wide C-shaped path
    waypoints = [
        0.0   0.0
        0.2   0.9
        1.5   1.3
        3.2   1.4
        3.8   0.2
        2.4  -0.9
        1.0  -0.8
        0.5  -1.2
        ];
    u_wp = linspace(s(1), s(end), size(waypoints,1));
    x = interp1(u_wp, waypoints(:,1), s, 'pchip');
    y = interp1(u_wp, waypoints(:,2), s, 'pchip');

elseif strcmp(lower(path_type), 'curve3')
    % S-shaped path with two main turns
    waypoints = [
        0.0   0.0
        0.4  -0.7
        0.2   0.8
        2.3   0.4
        2.6   1.4
        2.9   2.4
        3.4   3.0
        ];
    u_wp = linspace(s(1), s(end), size(waypoints,1));
    x = interp1(u_wp, waypoints(:,1), s, 'pchip');
    y = interp1(u_wp, waypoints(:,2), s, 'pchip');

elseif strcmp(lower(path_type), 'curve4')
    % Hardest: self-crossing loop shape; stress-test path
        t = s * 2*pi;
        scale = 0.8;   % smaller path so rover can complete it in 30 s
        x = scale * (0.5 + 4*s + 1.5*sin(t));
        y = scale * (1.5 + 1.2*cos(t));
else
    error('Unknown path type: %s', path_type);

end

% Shift every path so it starts at (0,0)
x = x - x(1);
y = y - y(1);

% Tangent angle at each sample point: direction from one point to the next.
dx  = diff(x);           % x change between consecutive points
dy  = diff(y);           % y change between consecutive points
psi = atan2(dy, dx);     % direction of that small step
psi = [psi; psi(end)];   % repeat last value so lengths match x, y

path.x   = x;
path.y   = y;
path.psi = psi;
path.type = path_type;   % remember which curve this is
end

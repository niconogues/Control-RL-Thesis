%% MAIN_TRAIN_PPO  Train a PPO controller to follow the path
clear; clc; close all;


%% 0) RUN SETTINGS; Change before Each Run

selectedCurve = 'curve1';   % 'curve1' / 'curve2' / 'curve3' / 'curve4'             !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
seedRun       = 1;          % 1, 2, 3, 4 or 5  (which of the 5 repeats)             !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

% Fixing the random number generator s.t. each seed gives a repeatable run.
rng(seedRun);

% Build the output file name automatically from the two choices above; e.g. 'trainedPPO_curve1_seed1.mat'.
saveName = sprintf('trainedPPO_%s_seed%d.mat', selectedCurve, seedRun);


%% 1) Define the OBSERVATION and the ACTION ------------------------------

% OBSERVATION = what the agent sees at each step, (lateral error ; heading error )

obsInfo = rlNumericSpec([2 1]);
obsInfo.Name        = 'observation';
obsInfo.Description = 'e_lat ; e_head';

% ACTION = what the agent decides at each step = omega_cmd 
actInfo = rlNumericSpec([1 1], ...
    'LowerLimit', -3, ...
    'UpperLimit',  3);
actInfo.Name = 'omega_cmd';

%% 2) Build the ENVIRONMENT ----------------------------------------------

% rlFunctionEnv links reset and step functions to the RL Toolbox.
env = rlFunctionEnv(obsInfo, actInfo, @stepFunction, @resetFunction);

%% 3) Create the PPO AGENT -----------------------------------------------
% NumHiddenUnit sets how many neurons are in each hidden layer.
initOpts = rlAgentInitializationOptions('NumHiddenUnit', 128);
agent    = rlPPOAgent(obsInfo, actInfo, initOpts);

% PPO settings ; must be set AFTER the agent is created.
dt = 0.020;                                    % control timestep, must match the step function
agent.AgentOptions.SampleTime        = dt;
agent.AgentOptions.ExperienceHorizon = 1024;   % steps collected per update
agent.AgentOptions.MiniBatchSize     = 128;    % samples per learning batch
agent.AgentOptions.NumEpoch          = 3;      % learning passes per update
agent.AgentOptions.ClipFactor        = 0.2;    % PPO "trust region" size
agent.AgentOptions.EntropyLossWeight = 0.01;   % encourages exploration
agent.AgentOptions.DiscountFactor    = 0.99;   % how much the future matters

agent.AgentOptions.ActorOptimizerOptions.LearnRate  = 1e-3;   % from 0.01 before (matlab's default) "how slowly we turn the knob"
agent.AgentOptions.CriticOptimizerOptions.LearnRate = 1e-3;

%% 4) Training OPTIONS ----------------------------------------------------

T_end    = 30.0;                    % same as the PID baseline
maxSteps = ceil(T_end / dt);        % max steps in one episode (= 1500)


trainOpts = rlTrainingOptions(...
    'MaxEpisodes',                350, ...
    'MaxStepsPerEpisode',         maxSteps, ...
    'ScoreAveragingWindowLength', 20, ...        % average reward over 20 episodes
    'StopTrainingCriteria',       'AverageReward', ...
    'StopTrainingValue',          150, ...       % stop early if "good enough"
    'Plots',                      'training-progress', ...
    'Verbose',                    false);

%% 5) TRAIN the agent -----------------------------------------------------

trainingStats = train(agent, env, trainOpts);

%% 6) SAVE the trained agent ---------------------------------------------

save(saveName, 'agent', 'trainingStats', 'selectedCurve', 'seedRun');
disp(['Training finished. Agent saved to ', saveName]);
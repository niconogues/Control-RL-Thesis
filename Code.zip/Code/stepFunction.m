function [Observation, Reward, IsDone, LoggedSignals] = stepFunction(Action, LoggedSignals)

%% STAGE 0: unpack what we stored last time (parameters, path, state)
p     = LoggedSignals.params;
path  = LoggedSignals.path;
x     = LoggedSignals.State(1);
y     = LoggedSignals.State(2);
theta = LoggedSignals.State(3);

%% STAGE 1: the ACTION is the commanded angular velocity (omega_cmd).
%           The agent gives us one number; we bound it to [-3, 3].

omega_cmd = Action(1); % RL actions are often passed as arrays.
omega_cmd = min(max(omega_cmd, p.omega_min), p.omega_max); % respect angular speed limits

%% STAGE 2: convert omega_cmd into wheel speeds (SAME as the PID baseline).

v_L = p.v_base - omega_cmd * p.L / 2;
v_R = p.v_base + omega_cmd * p.L / 2;
v_L = min(max(v_L, -p.v_max), p.v_max);   % respect wheel-speed limits
v_R = min(max(v_R, -p.v_max), p.v_max);

%% STAGE 3: move the rover with the unicycle / differential-drive model.

v     = (v_R + v_L) / 2;     % forward speed
omega = (v_R - v_L) / p.L;   % turning rate

% Move the rover forward for one controller timestep.
x     = x + v * cos(theta) * p.dt;
y     = y + v * sin(theta) * p.dt;
theta = theta + omega * p.dt;

% Keep theta in (-pi, pi]
theta = atan2(sin(theta), cos(theta));

% Advance simulation time
LoggedSignals.t = LoggedSignals.t + p.dt;

%% STAGE 4: measure the new path error after moving.
[e_lat, e_head] = computePathError(x, y, theta, path);

%% STAGE 5: compute the REWARD.

Reward = -p.a * e_lat^2 -p.b * e_head^2 -p.c * omega_cmd^2 + 0.1;

%% STAGE 6: should episode end?

IsDone = false;

% (a) Rover wandered too far from the path -> "lost". Big penalty + stop.
if abs(e_lat) > p.lost_thresh
    Reward = Reward - 100;
    IsDone = true;
end

% (b) Time ran out -> stop (no penalty).
if LoggedSignals.t >= p.T_end
    IsDone = true;
end

%% STAGE 7: save the new state and return the next observation.
LoggedSignals.State = [x; y; theta];
Observation = [e_lat; e_head];

end

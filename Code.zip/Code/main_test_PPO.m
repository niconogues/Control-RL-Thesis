%% MAIN_TEST_PPO  Simulate the trained PPO agent and plot the results
% Run main_train_PPO.m FIRST so that trainedPPO.mat exists.

clear; clc; close all;

%% 1. SETTINGS (same as the PID baseline) --------------------------------

L       = 0.15;     % wheelbase [m]
v_base  = 0.20;     % nominal forward speed [m/s]
v_max   = 0.40;     % maximum wheel speed [m/s]

dt      = 0.020;    % physics step [s]   (50 Hz) -> the rate PPO was trained at
T_end   = 30.0;     % total simulation time [s]

omega_max =  3.0;   % saturation on commanded angular velocity [rad/s]
omega_min = -3.0;

% Initial state of the rover (same as the PID baseline).
x     =  path.x(1);
y     =  path.y(1);           % starts on path
theta = path.psi(1) - 0.20;   % path tangent -0.2 (small heading error) [rad]

lost_threshold = 0.50;   % if |lateral error| > value, the line is lost [m]

%% 2. LOAD THE TRAINED PPO AGENT -----------------------------------------

load('trainedPPO_curve1_seed1.mat', 'agent'); %                                   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

% Use the agent's BEST (mean) action instead of random exploration, so the
% test run is repeatable and represents the learned policy.
agent.UseExplorationPolicy = false;


%% 3. THE PATH -----------------------------------------------------------

% Use the SAME curve the agent was trained on (see resetFunction.m).
path_type = 'curve1';            % 'curve1' / 'curve2' / 'curve3' / 'curve4'      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
seedRun = 1;                     %                                                !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
path = buildPath(path_type);

%% 4. INITIAL LOGS -------------------------------------------------------

N = round(T_end / dt) + 1;   % number of physics steps (+1 for t = 0)

t_log         = zeros(N, 1);
x_log         = zeros(N, 1);
y_log         = zeros(N, 1);
theta_log     = zeros(N, 1);
e_lat_log     = zeros(N, 1);
e_head_log    = zeros(N, 1);
omega_cmd_log = zeros(N, 1);
vL_log        = zeros(N, 1);
vR_log        = zeros(N, 1);

%% 5. MAIN SIMULATION LOOP -----------------------------------------------

t         = 0.0;
omega_cmd = 0.0;   % current command (updated every dt_ctrl by the agent)

for k = 1:N

% (A) SENSING: calculate the path errors.
    [e_lat, e_head] = computePathError(x, y, theta, path);

% (B) CONTROLLER UPDATE (PPO):
    % Ask the trained PPO agent for a steering command.
    % The observation is the same as during training: [e_lat; e_head].
    action    = getAction(agent, {[e_lat; e_head]});
    % getAction returns the action inside a cell, so take the first value.
    omega_cmd = action{1};
    % Keep omega_cmd within the same limits used during training.
    omega_cmd = min(max(omega_cmd, omega_min), omega_max);

% (C) CONVERT OMEGA_CMD TO WHEEL SPEEDS (same equations as PID).
    vL_cmd = v_base - omega_cmd * L / 2;
    vR_cmd = v_base + omega_cmd * L / 2;
    vL_cmd = min(max(vL_cmd, -v_max), v_max);   % wheel-speed limits
    vR_cmd = min(max(vR_cmd, -v_max), v_max);

% (D) LOG/STORE (before moving).
    t_log(k)         = t;
    x_log(k)         = x;
    y_log(k)         = y;
    theta_log(k)     = theta;
    e_lat_log(k)     = e_lat;
    e_head_log(k)    = e_head;
    omega_cmd_log(k) = omega_cmd;
    vL_log(k)        = vL_cmd;
    vR_log(k)        = vR_cmd;

% (E) UPDATE ROVER POSITION (kinematic model, one Euler step).
    v     = (vR_cmd + vL_cmd) / 2;
    omega = (vR_cmd - vL_cmd) / L;
    x     = x + v * cos(theta) * dt;
    y     = y + v * sin(theta) * dt;
    theta = theta + omega * dt;
    theta = atan2(sin(theta), cos(theta));   % wrap to (-pi, pi]

% (F) advance time.
    t = t + dt;
end

%% 6. PLOTS (same as the PID baseline) -----------------------------------

% Plot 1: desired path vs rover trajectory.
figure('Name', 'PPO Trajectory');
plot(path.x, path.y, 'k--', 'LineWidth', 1.5); hold on;
plot(x_log, y_log, 'b-', 'LineWidth', 1.5);
plot(x_log(1),   y_log(1),   'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
plot(x_log(end), y_log(end), 'rs', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
hold off;
xlabel('x [m]'); ylabel('y [m]');
title('PPO: Desired path vs. rover trajectory');
legend('Reference path', 'Rover trajectory', 'Start', 'End', 'Location', 'best');
grid on; axis equal;

% Plot 2: errors (lateral on top, heading in degrees below).
figure('Name', 'PPO Errors');
subplot(2, 1, 1);
plot(t_log, e_lat_log, 'b-', 'LineWidth', 1.2);
ylabel('Lateral error [m]'); title('PPO: Cross-track error'); grid on;
subplot(2, 1, 2);
plot(t_log, rad2deg(e_head_log), 'r-', 'LineWidth', 1.2);
ylabel('Heading error [deg]'); xlabel('Time [s]');
title('PPO: Heading error'); grid on;

% Plot 3: left and right wheel speeds.
figure('Name', 'PPO Wheel speeds');
plot(t_log, vL_log, 'b-', 'LineWidth', 1.2); hold on;
plot(t_log, vR_log, 'r-', 'LineWidth', 1.2);
yline( v_max, 'k:', 'v_{max}');
yline(-v_max, 'k:', '-v_{max}');
hold off;
xlabel('Time [s]'); ylabel('Wheel speed [m/s]');
title('PPO: Left and right wheel speeds over time');
legend('v_L', 'v_R', 'Location', 'best'); grid on;

% Plot 4: commanded angular velocity over time.
figure('Name', 'PPO Controller output');
plot(t_log, omega_cmd_log, 'm-', 'LineWidth', 1.2); hold on;
yline(omega_max, 'k:'); yline(omega_min, 'k:');
hold off;
xlabel('Time [s]'); ylabel('\omega_{cmd} [rad/s]');
title('PPO: Commanded angular velocity over time'); grid on;

%% 7. METRICS (same definitions as the PID baseline) ---------------------

mae_lat    = mean(abs(e_lat_log));               % mean absolute lateral error
max_lat    = max(abs(e_lat_log));                % worst lateral error
ctrl_eff   = sum(vL_log.^2 + vR_log.^2) * dt;    % control effort (energy proxy)

% Did the rover ever lose the line?
lost = false;
for i = 1:length(e_lat_log)
    if abs(e_lat_log(i)) > lost_threshold
        lost = true;
    end
end
completed = ~lost;

fprintf('\n================ PPO metrics ================\n');
fprintf('  Path type                  : %s\n', path.type);
fprintf('  Mean abs lateral error     : %.4f m\n', mae_lat);
fprintf('  Max abs lateral error      : %.4f m\n', max_lat);
fprintf('  Total control effort       : %.4f (m/s)^2 * s\n', ctrl_eff);
fprintf('  Completed without losing it: %s\n', string(completed));
fprintf('=============================================\n\n');
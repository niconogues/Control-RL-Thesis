function [InitialObservation, LoggedSignals] = resetFunction()

% Parameters (SAME values as the PID baseline)
params.L           = 0.15;    % wheelbase [m]
params.v_base      = 0.20;    % base forward speed [m/s]
params.v_max       = 0.40;    % maximum wheel speed [m/s]
params.dt          = 0.020;   % physics and control timesteps ; (how often we act) [s] [=50Hz] one episode has: 30/0.020 = 1500 steps

params.T_end       = 30.0;    % maximum episode time [s] 

params.omega_max   =  3.0;    % max angular velocity command [rad/s]
params.omega_min   = -3.0;    % min angular velocity command [rad/s]

params.lost_thresh = 0.50;    % if |e_lat| > this, the rover is "lost" [m]

% Reward weights (how strongly we punish each error)
params.a = 10.0;   % weight on lateral error  (stay on the path) ; strongly punish lateral error
params.b = 1.0;    % weight on heading error  (face the right way) ; mildly punish heading error
params.c = 0.05;   % weight on control effort (don't steer wildly) ; slightly punish aggressive steering

% Build the path (same as the baseline)
path_type = 'curve1';       % !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
path = buildPath(path_type);

% Initial Conditions for Rover
x0     = path.x(1);                 %+ 0.05 * (2*rand - 1);   if I want a random  small random x offset [m]
y0     = path.y(1);                       %+ 0.05 * (2*rand - 1);   if I want a random  small random y offset [m]
theta0 = path.psi(1) - 0.20 ;       % + 0.10 * (2*rand - 1); if I want a random heading near the baseline's -0.20


% Store everything the step function needs
LoggedSignals.State  = [x0; y0; theta0];   % rover state [x; y; theta]
LoggedSignals.t      = 0.0;                % simulation clock
LoggedSignals.params = params;
LoggedSignals.path   = path;

% First observation = [ lateral error; heading error ]
[e_lat, e_head] = computePathError(x0, y0, theta0, path);
InitialObservation = [e_lat; e_head];

end

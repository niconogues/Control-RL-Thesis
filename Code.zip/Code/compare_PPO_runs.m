%% COMPARE_PPO_RUNS  Compare 5 PPO training runs for ONE curve
%
%  This script DOES NOT TRAIN anything. It loads the 5 already-trained PPO
%  agents for one curve and makes 2 plots:
%      Plot 1: the training reward curve of all 5 seeds,
%      Plot 2: the driven trajectory of all 5 seeds on the curve.
%
%  BEFORE RUNNING:
%    Train the 5 agents first with main_train_PPO.m (seedRun = 1..5, same
%    curve). That creates the files:
%        trainedPPO_<curve>_seed1.mat ... trainedPPO_<curve>_seed5.mat
%
%  Required files in the same folder:
%    resetFunction.m, buildPath.m, computePathError.m, and the 5 .mat files.

clear; clc; close all;

%% 0) SETTINGS  <-- pick the curve you want to compare --------------------

selectedCurve = 'curve1';   % 'curve1' / 'curve2' / 'curve3' / 'curve4'
nSeeds        = 5;          % we compare 5 runs

% Reuse the EXACT rover + simulation values the agent was trained with, by
% calling resetFunction once (so we don't retype L, v_base, dt, etc.).
[~, S] = resetFunction();
cfg = S.params;             % L, v_base, v_max, dt, T_end, omega_min/max ...

% Fixed starting state, also taken straight from resetFunction.
cfg.x0     = S.State(1);
cfg.y0     = S.State(2);
cfg.theta0 = S.State(3);

% Build the path once; every agent follows this same curve.
path = buildPath(selectedCurve);

%% 1) LOAD THE 5 TRAINED AGENTS ------------------------------------------

agents       = cell(nSeeds, 1);   % the 5 PPO agents
rewardCurves = cell(nSeeds, 1);   % each agent's per-episode reward curve

for s = 1:nSeeds
    fname = sprintf('trainedPPO_%s_seed%d.mat', selectedCurve, s);

    % Clear message if a file is missing (e.g. you forgot to train seed 4).
    if ~isfile(fname)
        error('Missing file %s. Train it first with main_train_PPO.m.', fname);
    end

    data = load(fname, 'agent', 'trainingStats');

    % Use the agent's best (mean) action, not random exploration, so the
    % test run is repeatable.
    data.agent.UseExplorationPolicy = false;

    agents{s}       = data.agent;
    rewardCurves{s} = data.trainingStats.EpisodeReward(:);  % one value/episode
end

%% 2) PLOT 1: training reward curve of all 5 seeds ------------------------

figure('Name', 'PPO training reward (all seeds)');
hold on;
for s = 1:nSeeds
    plot(rewardCurves{s}, 'LineWidth', 1.2, 'DisplayName', sprintf('seed %d', s));
end
hold off;
xlabel('Episode'); ylabel('Episode reward');
title(sprintf('PPO training reward - all seeds (%s)', selectedCurve));
legend('Location', 'best'); grid on;

%% 3) PLOT 2: driven trajectory of all 5 seeds ----------------------------

figure('Name', 'PPO trajectories (all seeds)');
plot(path.x, path.y, 'k--', 'LineWidth', 1.5, 'DisplayName', 'Reference path');
hold on;
for s = 1:nSeeds
    traj = simulatePPO(agents{s}, path, cfg);   % drive this agent on the curve
    plot(traj.x, traj.y, '-', 'LineWidth', 1.2, ...
        'DisplayName', sprintf('seed %d', s));
end
hold off;
xlabel('x [m]'); ylabel('y [m]');
title(sprintf('PPO trajectories - all seeds (%s)', selectedCurve));
legend('Location', 'best'); grid on; axis equal;

disp('Comparison plots created.');


%% ======================================================================
%  LOCAL HELPER FUNCTION
%  ======================================================================

function traj = simulatePPO(agent, path, cfg)
% SIMULATEPPO  Drive one trained PPO agent on the path and return its x,y track.
%
%  Each pass of the loop is ONE reinforcement-learning step:
%    1) OBSERVATION : what the agent sees = [lateral error ; heading error].
%    2) ACTION      : the agent turns that into one number, omega_cmd
%                     (how hard to steer), clipped to [-3, 3].
%    3) STEP        : apply omega_cmd to the rover and move forward one dt.
%  (No reward is needed here - the agent is already trained.)

    N = round(cfg.T_end / cfg.dt) + 1;      % number of steps

    x_log = zeros(N, 1);
    y_log = zeros(N, 1);

    % Start from the fixed initial state.
    x = cfg.x0; y = cfg.y0; theta = cfg.theta0;

    for k = 1:N
        % 1) OBSERVATION
        [e_lat, e_head] = computePathError(x, y, theta, path);

        % 2) ACTION (ask the agent, then clip)
        action    = getAction(agent, {[e_lat; e_head]});
        omega_cmd = action{1};
        omega_cmd = min(max(omega_cmd, cfg.omega_min), cfg.omega_max);

        x_log(k) = x; y_log(k) = y;   % save position before moving

        % 3) STEP: omega_cmd -> wheel speeds -> move one dt (same physics
        %    as training and the PID baseline).
        vL = cfg.v_base - omega_cmd * cfg.L / 2;
        vR = cfg.v_base + omega_cmd * cfg.L / 2;
        vL = min(max(vL, -cfg.v_max), cfg.v_max);
        vR = min(max(vR, -cfg.v_max), cfg.v_max);

        v     = (vR + vL) / 2;          % forward speed
        omega = (vR - vL) / cfg.L;      % turning rate
        x     = x + v * cos(theta) * cfg.dt;
        y     = y + v * sin(theta) * cfg.dt;
        theta = theta + omega * cfg.dt;
        theta = atan2(sin(theta), cos(theta));   % wrap to (-pi, pi]
    end

    traj.x = x_log; traj.y = y_log;
end

function [e_lat, e_head] = computePathError(x, y, theta, path) % This function compares the rover's position & direction with the path. Outputs: e_lat & e_head
% 1st Step: closest point on the path ?
closest_idx   = 1;          % start by assuming point 1 is the closest

% Calculate distance from rover to the first path point.
dx_1 = x - path.x(1);
dy_1 = y - path.y(1);

small_dist = sqrt(dx_1^2 + dy_1^2);

% Now check all other path points one by one.
for i = 1:length(path.x)

    % Difference between rover position and current path point.
    dx = x - path.x(i);
    dy = y - path.y(i);

    dist = sqrt(dx^2 + dy^2);

    % If this point is closer than the previous closest point, remember this point as the new closest point:
    if dist < small_dist
        small_dist = dist;
        closest_idx = i;
    end
end

% 2nd Step: path direction @ closest point?
psi = path.psi(closest_idx);

% 3rd Step: Lateral error ?
% Vector from closest path point to rover...
delta_x = x - path.x(closest_idx);
delta_y = y - path.y(closest_idx);

% ... projected onto the direction perpendicular to the path.
% This gives signed sideways error.
e_lat = -sin(psi) * delta_x + cos(psi) * delta_y; % +ve = rover is @ the LEFT

%        : Heading error ?
% Wrap angle to the range (-pi, pi].
e_head = atan2(sin(psi - theta), cos(psi - theta));
end
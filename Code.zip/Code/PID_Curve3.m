% Since PID gain controllers are tailored per curve; this code simulates the
% rover driving through the path "Curve3"

clear; clc; close all;

%%  1. SETTINGS — change these to experiment

% Rover's prmtrs:
L           = 0.15;    % wheelbase [m]
v_base      = 0.20;    % nominal forward speed [m/s]
v_max       = 0.40;    % maximum wheel speed [m/s]

% Simulation: timing
dt      = 0.020;       % physics step [s]   (50 Hz)
T_end   = 30.0;        % total simulation time [s]

% PID gains for controller
Kp = 25.0;              % proportional gain
Ki = 0;              % integral gain
Kd = 7;              % derivative gain
% Heading error gain
k_heading = 1.25;       % weight on heading-error damping term

omega_max =  3.0;      % saturation on commanded angular velocity [rad/s]
omega_min = -3.0;

% Parameter ´limit´ for rover; has it lost the line ?
lost_threshold = 0.50;   % if |lateral error| > value; line = lost [metrs]


%%  2. THE PATH

% Path to follow:
path_type = 'curve3';   % 'curve1' / 'curve2' / 'curve3' / 'curve4'
path = buildPath(path_type);    % Actual function; found under Point_7

% Initial state of rover before simulation
x     =  path.x(1);
y     =  path.y(1);           % starts on path
theta = path.psi(1) - 0.20;   % path tangent -0.2 (small heading error) [rad]

%% 3. Initial Logs

% How many simulation steps we will run.
% +1 so that the very first instant (t = 0) is also counted.
N = round(T_end / dt) + 1;

t_log         = zeros(N, 1);   % time
x_log         = zeros(N, 1);   % rover x position
y_log         = zeros(N, 1);   % rover y position
theta_log     = zeros(N, 1);   % rover heading
e_lat_log     = zeros(N, 1);   % lateral (cross-track) error
e_head_log    = zeros(N, 1);   % heading error
omega_cmd_log = zeros(N, 1);   % commanded angular velocity
vL_log        = zeros(N, 1);   % left wheel speed
vR_log        = zeros(N, 1);   % right wheel speed

% set time/iterations - dependent errors to 0; s.t. initial conditions can't be compared with
e_lat_integral = 0.0; % integral error; as a summation of errors over time
e_lat_prev = 0.0;     % derivative error; looks at the previous error @ (k-1)


%% 4. Main Simulation Loop
t = 0.0;                 % simulation clock starts at zero
for k = 1:N
    
    % (a) SENSING: calculate the path errors
    % Compare the rover pose (x, y, theta) against the path and get:
    %   e_lat  = how far we are to the side of the path
    %   e_head = how badly our heading is misaligned with the path tangent
    [e_lat, e_head] = computePathError(x, y, theta, path);

    % (b) CONTROLLER UPDATE:
    e_lat_integral = e_lat_integral + (e_lat * dt); % adds lateral error over time (error * dt)
    e_lat_derivative = (e_lat - e_lat_prev) / dt;   % responds to how fast the lateral error is changing
    
    % "PID + heading term" formula for angular vel. output; signs are very important and must be explained
    omega_cmd = -Kp * e_lat  -Ki * e_lat_integral  -Kd * e_lat_derivative  +k_heading * e_head;

    % (b2) omega_cmd SATURATIONS; important bc it adds limits to motor; bounding choices to be realistic
    if omega_cmd > omega_max
       omega_cmd = omega_max;
    elseif omega_cmd < omega_min
       omega_cmd = omega_min;
    end
    
    % Remember this error (k) for the derivative term that uses the next one (k+1) ; meaning (k-1) and (k) for next run
    e_lat_prev = e_lat;


    % (c) CONVERT OMEGA_CMD TO WHEEL VELS.: comes from eqs: v = (vR+vL)/2 and omega = (vR-vL)/L, by solving for vR and VL
    vL_cmd = v_base - omega_cmd * L / 2;   % left wheel
    vR_cmd = v_base + omega_cmd * L / 2;   % right wheel

    % (c2) velocity SATURATIONS; important bc same pple as omega
    if vL_cmd > v_max       % Left wheel
        vL_cmd = v_max;
    elseif vL_cmd < -v_max
        vL_cmd = -v_max;
    end
    if vR_cmd > v_max           % Right wheel:
        vR_cmd = v_max;
    elseif vR_cmd < -v_max
        vR_cmd = -v_max;
    end

    % (d) LOG/STORE (before moving; storing data)
    t_log(k)         = t;
    x_log(k)         = x;
    y_log(k)         = y;
    theta_log(k)     = theta;
    e_lat_log(k)     = e_lat;
    e_head_log(k)    = e_head;
    omega_cmd_log(k) = omega_cmd;
    vL_log(k)        = vL_cmd;
    vR_log(k)        = vR_cmd;

    % (f) UPDATE ROVER POSITION (kinematic model, one Euler step)
    v     = (vR_cmd + vL_cmd) / 2;
    omega = (vR_cmd - vL_cmd) / L;

    x = x + v *cos(theta) *dt;
    y = y + v *sin(theta) *dt;
    theta = theta + omega *dt;
    
    % force theta wrapped to the range (-pi, pi]:
    theta = atan2(sin(theta), cos(theta));

    % (g) advance time step; next run
    t = t + dt;
end


%% 5. Plots

% Plot 1: desired path v. rover trajectory.
figure('Name', 'Trajectory');
plot(path.x, path.y, 'k--', 'LineWidth', 1.5); hold on;       % desired path
plot(x_log, y_log, 'b-', 'LineWidth', 1.5);                   % rover trajectory
plot(x_log(1),   y_log(1),   'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g'); % start
plot(x_log(end), y_log(end), 'rs', 'MarkerSize', 10, 'MarkerFaceColor', 'r'); % end
hold off;
xlabel('x [m]'); ylabel('y [m]');
title('Desired path vs. rover trajectory');
legend('Reference path', 'Rover trajectory', 'Start', 'End', 'Location', 'best');
grid on; axis equal;

% Plot 2: errors
figure('Name', 'Errors');
% lateral error.
subplot(2, 1, 1);
plot(t_log, e_lat_log, 'b-', 'LineWidth', 1.2);
ylabel('Lateral error [m]');
title('Cross-track error');
grid on;
% heading error (converted to degrees w/ function rad2deg()).
subplot(2, 1, 2);
plot(t_log, rad2deg(e_head_log), 'r-', 'LineWidth', 1.2);
ylabel('Heading error [deg]');
xlabel('Time [s]');
title('Heading error');
grid on;

% Plots 3: L&R wheel speeds
figure('Name', 'Wheel speeds');
plot(t_log, vL_log, 'b-', 'LineWidth', 1.2); hold on;
plot(t_log, vR_log, 'r-', 'LineWidth', 1.2);
yline( v_max, 'k:', 'v_{max}');
yline(-v_max, 'k:', '-v_{max}');
hold off;
xlabel('Time [s]'); ylabel('Wheel speed [m/s]');
title('Left and right wheel speeds over time');
legend('v_L', 'v_R', 'Location', 'best');
grid on;

% Plot 4: commanded angular vel. (w_cmd) over time
figure('Name', 'Controller output');
plot(t_log, omega_cmd_log, 'm-', 'LineWidth', 1.2); hold on;
yline(omega_max, 'k:'); yline(omega_min, 'k:');
hold off;
xlabel('Time [s]'); ylabel('\omega_{cmd} [rad/s]');
title('Commanded angular velocity over time');
grid on;


%% 6. Actual Metrics / Scalar results

mae_lat    = mean(abs(e_lat_log));               % mean absolute lateral error
max_lat    = max(abs(e_lat_log));                % worst lateral error
ctrl_eff   = sum(vL_log.^2 + vR_log.^2) * dt;    % control effort (energy proxy)

% Is rover lost ? Has it lost the line path ? 
lost = false;   % assume the rover did not lose the line
for i = 1:length(e_lat_log)
    if abs(e_lat_log(i)) > lost_threshold
        lost = true;   % rover went too far away from the path
    end
end
if lost == true
    completed = false;
else
    completed = true;
end

fprintf('\n================ Baseline metrics ================\n');
fprintf('  Path type                  : %s\n', path_type);
fprintf('  Mean abs lateral error     : %.4f m\n', mae_lat);
fprintf('  Max abs lateral error      : %.4f m\n', max_lat);
fprintf('  Total control effort       : %.4f (m/s)^2 * s\n', ctrl_eff);
fprintf('  Completed without losing it: %s\n', string(completed));
fprintf('==================================================\n\n');